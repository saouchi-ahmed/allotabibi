const translations = {
  fr: {
    "Home": "Accueil",
    "About Us": "À propos",
    "Doctors": "Médecins",
    "News": "Actualités",
    "Contact": "Contact",
    "Login / Register": "Connexion / Inscription",
    "Let's make your life happier": "Rendons votre vie plus heureuse",
    "Healthy Living": "Vie saine",
    "Let's Consult": "Consultons ou Faisons une consultation",
    "Learn More": "En savoir plus",
    "Latest News": "Dernières actualités",
    "Déposer une plainte": "Déposer une plainte",
    "Submit Request": "Envoyer la requête",
    "AmbulanceAtHome": "Ambulance à domicile",
    "Teleconsultation": "Téléconsultation",
    "SoinsDomicile": "Soins à domicile",
    "MedecinDomicile": "Médecin à domicile",
    "InfirmierDomicile": "Infirmier à domicile",
    "Clinique Elysa":"Clinique Elysa",
    "Clinique Yachfine":"Clinique Yachfine",
    "Notre mission":"Notre mission",
    "Learn More":" En savoir plus",
    "More":"Plus",
    "Les partenaires":"Les partenaires",
    "post1":" Dans le cadre de la participation de l’institution Allo Tabibi au colloque national hybride intitulé « La communication médicale comme levier pour établir une relation de confiance entre médecins et patients », organisé sous le patronage du Ministère de l’Enseignement Supérieur et de la Recherche Scientifique. Cet événement scientifique a été organisé par la Faculté des Sciences Humaines et Sociales, avec la participation d’un groupe d’élite de chercheurs et de spécialistes dans les domaines de la médecine et des sciences de la communication.",
    "post2": "✅ Notre participation à la cinquième édition de la caravane médicale #fondation_nes_el_khir\n✅ El Karma, commune El Hadjar\n ✅ Allo Tabibi remercie tous les participants.\n",
    "post3":"🔷 Notre participation au colloque national sur la numérisation du secteur de la pêche maritime et de l’aquaculture, supervisé par le Ministre de la Pêche Maritime et des Produits de la Pêche, M. Ahmed Bedani, le mardi 8 octobre 2024, au siège de la Direction de la Pêche Maritime et de l’Aquaculture de la wilaya d’Alger.",
    "Latest News":"Dernières actualités",
    "Lire plus":"Lire plus",
    "Full name":"Nom complet",
    "Number":"Numéro",
    "Enter message..":"Saisir le message...",
    "Submit Request":"Soumettre la demande",
    "Terms & Condition":"Termes et conditions",
    "One-Fitness":"",
    "adr":"aic elboni annaba",
    "Déposer une plainte":"Déposer une plainte",
    "Social Media":" Réseaux sociaux",
    "Company":" Entreprise",
    "t1":" N'attendez pas de prendre en main votre santé, à l'aide de nos médecins, Allotabibi vous offre un accès aux soins en quelques clics.",
    "Welcome to Allotabibi":"Welcome to Allotabibi",
    "q1":"Comment ça marche ?",
    "q3":"Tout savoir sur nos prestations",
    "t3":"1. Vous complétez le questionnaire médical",
    "t4":"2. Un docteur consulte votre questionnaire",
    "t5":" Sur la base des réponses aux questions posées, le médecin consulte votre demande et échange avec vous directement par visioconférence et/ou par messagerie instantanée.",
    "t6":"3. Votre traitement à distance",
    "t7":" À la suite de votre téléconsultation, le médecin vous transmettra votre document médical récupérable dans votre espace personnel. Vous aurez la possibilité de récupérer votre traitement en pharmacie sans imprimer le document.",
    "t8":" Un service post téléconsultation",
    "t9":" Vos données de santé sont stockées chez un hébergeur sécurisé, vous restez propriétaire de celles-ci. A l'aide de notre outil de diagnostic, les médecins ont la possibilité de suivre votre santé à distance et de vous recontacter en cas de besoin.",
    "t2":" Inspiré de millions de consultations physiques, le questionnaire est une étape préalable au diagnostic médical. Nous vous demandons de répondre précisément aux questions pour contribuer à une prise en charge optimale par nos médecins. Sur la base des réponses aux questions posées, le médecin consulte votre demande et échange avec vous directement par visioconférence et/ou par messagerie instantanée.",
    "ALLO TABIBI est une plateforme innovante dédiée à la présentation et à la coordination de services médicaux et paramédicaux à domicile. Nous mettons à votre disposition une équipe pluridisciplinaire composée de médecins, aides-soignants, agents de santé, kinésithérapeutes et psychologues, ainsi qu'un service intégré de médecine du travail. Notre objectif est d'offrir un accès simplifié et rapide aux soins, en collaboration avec un vaste réseau de: médecins spécialisés, cliniques privées et laboratoires d'analyses médicales. Grâce à un équipement médical de pointe et un service de transport sanitaire par ambulance, nous garantissons un accompagnement médical sécurisé 24h/24 et 7j/7.":"ALLO TABIBI est une plateforme innovante dédiée à la présentation et à la coordination de services médicaux et paramédicaux à domicile. Nous mettons à votre disposition une équipe pluridisciplinaire composée de médecins, aides-soignants, agents de santé, kinésithérapeutes et psychologues, ainsi qu'un service intégré de médecine du travail. Notre objectif est d'offrir un accès simplifié et rapide aux soins, en collaboration avec un vaste réseau de: médecins spécialisés, cliniques privées et laboratoires d'analyses médicales. Grâce à un équipement médical de pointe et un service de transport sanitaire par ambulance, nous garantissons un accompagnement médical sécurisé 24h/24 et 7j/7.",
    "La mission de ALLO TABIBI est de fournir des soins à domicile de haute qualité, personnalisés et respectueux, afin de permettre à nos clients de maintenir leur autonomie, leur bien-être et leur dignité dans un environnement familier. Nous nous engageons à améliorer la qualité de vie des personnes âgées, des personnes en situation de handicap ou de dépendance, et de leurs familles.":
      "La mission d’ALLO TABIBI est de fournir des soins à domicile de haute qualité, personnalisés et respectueux, afin de permettre à nos clients de conserver leur autonomie, leur bien-être et leur dignité dans un cadre familier. Nous nous engageons à améliorer la qualité de vie des personnes âgées, des personnes en situation de handicap ou de dépendance, ainsi que de leurs familles."
    
      // ajoutez les autres mots ici
  },
  ar: {
    "Home": "الرئيسية",
    "q1":"كيف يعمل؟",
    "t3":"1. تقوم بملء الاستبيان الطبي",
    "t4":"2. يقوم الطبيب بمراجعة استبيانك",
    "t5":"بناءً على إجابات الأسئلة المطروحة، يقوم الطبيب بمراجعة طلبك ويتواصل معك مباشرة عبر الاتصال المرئي و/أو الرسائل الفورية.",
    "t6":"علاجك عن بُعد.3",
    "t7":"بعد استشارتك الطبية عن بُعد، سيقوم الطبيب بإرسال مستندك الطبي الذي يمكنك استرجاعه من خلال حسابك الشخصي. سيكون بإمكانك الحصول على علاجك من الصيدلية دون الحاجة إلى طباعة المستند.",
    "t8":"خدمة ما بعد الاستشارة الطبية عن بُعد",
    "t9":"تُخزن بيانات صحتك لدى مزوّد استضافة آمن، وتبقى أنت المالك الوحيد لها.باستخدام أداة التشخيص الخاصة بنا، يمكن للأطباء متابعة صحتك عن بُعد والتواصل معك عند الحاجة",
    "q2":"كل ما تريد معرفته عن خدماتنا",
    "About Us": "من نحن",
    "Doctors": "الأطباء",
    "News": "الأخبار",
    "Contact": "اتصل بنا",
    "Login / Register": "تسجيل الدخول / إنشاء حساب",
    "Let's make your life happier": "لنجعل حياتك أكثر سعادة",
    "Healthy Living": "حياة صحية",
    "Let's Consult": "استشارة الآن",
    "Learn More": "أعرف أكثر",
    "Latest News": "آخر الأخبار",
    "Déposer une plainte": "تقديم شكوى",
    "Submit Request": "إرسال الطلب",
    "AmbulanceAtHome": "سيارة إسعاف في المنزل",
    "Teleconsultation": "الاستشارة عن بعد",
    "SoinsDomicile": "الرعاية المنزلية",
    "MedecinDomicile": "طبيب في المنزل",
    "InfirmierDomicile": "ممرض في المنزل",
    "Clinique Elysa":"مصحة اليزا",
    "Clinique Yachfine":"مصحة يشفين",
    "Notre mission":"مهمتنا",
    "Learn More":"معرفة المزيد",
    "Number":"رقم",
    "La mission de ALLO TABIBI est de fournir des soins à domicile de haute qualité, personnalisés et respectueux, afin de permettre à nos clients de maintenir leur autonomie, leur bien-être et leur dignité dans un environnement familier. Nous nous engageons à améliorer la qualité de vie des personnes âgées, des personnes en situation de handicap ou de dépendance, et de leurs familles.":
      "مهمة ألو طبيبي هي تقديم رعاية منزلية عالية الجودة، مخصصة ومحترمة، بهدف تمكين عملائنا من الحفاظ على استقلاليتهم ورفاهيتهم وكرامتهم في بيئة مألوفة. نحن ملتزمون بتحسين جودة الحياة لكبار السن، والأشخاص ذوي الإعاقات أو الاعتماد على الآخرين، وكذلك لعائلاتهم.",
    "Les partenaires":"العملاء",
  "Latest News": "آخر الأخبار",
"post1":"من مشاركة مؤسسة ألو طبيبي في الملتقى الوطني الهجين حول الاتصال الطبي كرافعة لبناء علاقة ثقة بين الأطباء والمرضى، وذلك تحت رعاية وزارة التعليم العالي والبحث العلمي. نُظِّم هذا الحدث العلمي من طرف كلية العلوم الإنسانية والاجتماعية، وبمشاركة نخبة من الباحثين والمختصين في مجالات الطب وعلوم الاتصال."  ,
"post2": "✅ مشاركتنا في النسخة الخامسة من القافلة الطبية #fondation_nes_el_khir\n✅ قرية الكرمة، بلدية الحجار\n✅ ألو طبيبي تشكر جميع المشاركين\n",
"post3":"🔷 مشاركانا في الندوة وطنية حول رقمنة قطاع الصيد البحري وتربية المائيات. التي أشرف عليها وزير الصيد البحري والمنتجات الصيدية، السيد أحمد بداني، يوم الثلاثاء 08 أكتوبر 2024، بمقر مديرية الصيد البحري وتربية المائيات لولاية الجزائر",
"Déposer une plainte":"تقديم شكوى",  
"Full name":"الاسم الكامل",
"Submit Request":" إرسال الطلب",
"Enter message..":"أدخل الرسالة...",
"Lire plus":"المزيد",
"One-Fitness":"",
"adr":"البوني عنابة",
"Social Media":" وسائل التواصل الاجتماعي",
"Company":"شركة",
"More":"المزيد",
"Welcome to Allotabibi":"مرحباً بكم في ألو طبيبي",
"ALLO TABIBI est une plateforme innovante dédiée à la présentation et à la coordination de services médicaux et paramédicaux à domicile. Nous mettons à votre disposition une équipe pluridisciplinaire composée de médecins, aides-soignants, agents de santé, kinésithérapeutes et psychologues, ainsi qu'un service intégré de médecine du travail. Notre objectif est d'offrir un accès simplifié et rapide aux soins, en collaboration avec un vaste réseau de: médecins spécialisés, cliniques privées et laboratoires d'analyses médicales. Grâce à un équipement médical de pointe et un service de transport sanitaire par ambulance, nous garantissons un accompagnement médical sécurisé 24h/24 et 7j/7.":"ALLO TABIBI هي منصة مبتكرة مخصصة لتقديم وتنسيق الخدمات الطبية وشبه الطبية في المنزل. نحن نقدم لك فريقًا متعدد التخصصات يتكون من الأطباء ومساعدي التمريض والعاملين الصحيين وأخصائيي العلاج الطبيعي وعلماء النفس، بالإضافة إلى خدمة الصحة المهنية المتكاملة. هدفنا هو توفير الوصول المبسط والسريع إلى الرعاية، بالتعاون مع شبكة واسعة من: الأطباء المتخصصين والعيادات الخاصة ومختبرات التحاليل الطبية. بفضل المعدات الطبية الحديثة وخدمة النقل بسيارات الإسعاف، فإننا نضمن الدعم الطبي الآمن على مدار الساعة طوال أيام الأسبوع.",
"Terms & Condition":"الشروط والأحكام",
"t2": "مستوحى من ملايين الاستشارات الطبية الحضورية، يُعد الاستبيان خطوة تمهيدية للتشخيص الطبي. نطلب منكم الإجابة بدقة على الأسئلة للمساهمة في تقديم رعاية مثلى من قبل أطبائنا. بناءً على الإجابات المقدمة، يقوم الطبيب بمراجعة طلبكم ويتواصل معكم مباشرة عبر الفيديو أو الرسائل الفورية.",
"t1":"لا تنتظر لتولي رعاية صحتك، فبمساعدة أطبائنا، يمنحك ألو طبيبي وصولاً إلى الرعاية الصحية ببضع نقرات فقط.",
// ajoutez les autres mots ici
  }
};

function changerLangue() {
  const langue = document.getElementById("language-select").value;

  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.getAttribute("data-i18n");
    if (translations[langue] && translations[langue][key]) {
      el.textContent = translations[langue][key];
    }
  });

  if (langue === "ar") {
    document.body.dir = "rtl";
    document.body.style.textAlign = "right";
    document.body.style.fontFamily = "'Marhey-VariableFont_wght', sans-serif";
  } else {
    document.body.dir = "ltr";
    document.body.style.textAlign = "left";
    document.body.style.fontFamily = "system-ui, sans-serif";
  }
}
