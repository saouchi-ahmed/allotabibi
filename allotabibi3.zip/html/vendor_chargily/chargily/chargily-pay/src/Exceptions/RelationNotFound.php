<?php

namespace Chargily\ChargilyPay\Exceptions;

use Exception;

final class RelationNotFound extends Exception
{
}
