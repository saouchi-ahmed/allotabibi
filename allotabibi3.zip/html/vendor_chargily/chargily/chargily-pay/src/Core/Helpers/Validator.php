<?php

namespace Chargily\ChargilyPay\Core\Helpers;

use Rakit\Validation\Validator as RakitValidator;

class Validator extends RakitValidator
{
}
