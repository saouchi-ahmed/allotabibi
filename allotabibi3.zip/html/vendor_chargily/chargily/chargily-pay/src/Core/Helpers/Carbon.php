<?php

namespace Chargily\ChargilyPay\Core\Helpers;

use Carbon\Carbon as CarbonCarbon;

class Carbon extends CarbonCarbon
{
}
