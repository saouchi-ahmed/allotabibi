<?php

namespace Chargily\ChargilyPay\Core\Helpers;

use Medboubazine\NumberFormatter\NumberFormat;

class NumFormat extends NumberFormat
{
}
