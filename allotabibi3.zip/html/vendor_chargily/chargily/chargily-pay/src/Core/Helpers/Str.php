<?php

namespace Chargily\ChargilyPay\Core\Helpers;

use Illuminate\Support\Str as SupportStr;

class Str extends SupportStr
{
}
