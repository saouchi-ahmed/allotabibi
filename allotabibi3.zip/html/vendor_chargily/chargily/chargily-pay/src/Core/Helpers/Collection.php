<?php

namespace Chargily\ChargilyPay\Core\Helpers;

use Illuminate\Support\Collection as SupportCollection;

class Collection extends SupportCollection
{
}
