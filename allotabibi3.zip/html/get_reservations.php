<?php
include 'config.php';
if ($conn->connect_error) {
    die("Échec de connexion : " . $conn->connect_error);
}
session_start();
$id_medsin=$_SESSION['id_medsin'];
$sql = "SELECT * from reservation_client where paye='yes'
        ORDER BY `date` DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['nom']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tel']) . "</td>";
        echo "<td>" . htmlspecialchars($row['age']) . "</td>";
        echo "<td>" . htmlspecialchars($row['date']) . "</td>";
        echo "<td>" . htmlspecialchars($row['service']) . "</td>";
        echo "<td>" . htmlspecialchars($row['specialite']) . "</td>";
        echo "<td>" . htmlspecialchars($row['paye']) . "</td>";
        echo "<td> <a class='btn btn-primary' href='" . htmlspecialchars($row['link_appel']) . "'> Rejoindre l'appel</a> </td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5' class='text-center text-muted'>Aucune réservation trouvée.</td></tr>";
}
$conn->close();
?>
