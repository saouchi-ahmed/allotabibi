<?php


$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'allotabibi2';
/*
$servername = "srv90";
$username = "tcyspvwh_a";
$password = "oJZ.k.v8057D";
$dbname = "tcyspvwh_allotabibi";
*/
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



?>
