<?php 

$specialite =  $_GET['specialite'] ;
$service_time=  $_GET['service_time'] ;
$service_totale=  $_GET['service_totale'] ;
//echo'lllll';


$patient_array=array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
if($service_time=='rendevou'){
     $patient_array= [
        'nom' => $_POST['nom'] ?? '',
        'prenom' => $_POST['prenom'] ?? '',
        'tel' => $_POST['tel'] ?? '',
        'email' => $_POST['email'] ?? '',
        'age' => $_POST['age'] ?? '',
        'rendezvous' => $_POST['rendezvous'] ?? '',
        'diabete' => $_POST['diabete'] ?? '',
        'coeur' => $_POST['coeur'] ?? '',
        'tension' => $_POST['tension'] ?? '',
        'cancer' => $_POST['cancer'] ?? '',
        'sida' => $_POST['sida'] ?? '',
        'specialite'=>  $specialite ?? '',
        'service_totale'=>  $service_totale ?? '',
        'service_time'=>  $service_time ?? '',
       
    ];

}else{

     $patient_array= [
        'nom' => $_POST['nom'] ?? '',
        'prenom' => $_POST['prenom'] ?? '',
        'tel' => $_POST['tel'] ?? '',
        'email' => $_POST['email'] ?? '',
        'age' => $_POST['age'] ?? '',
        'rendezvous' => 'mediatement',
        'diabete' => $_POST['diabete'] ?? '',
        'coeur' => $_POST['coeur'] ?? '',
        'tension' => $_POST['tension'] ?? '',
        'cancer' => $_POST['cancer'] ?? '',
        'sida' => $_POST['sida'] ?? '',
        'specialite'=>  $specialite ?? '',
        'service_totale'=>  $service_totale ?? '',
        'service_time'=>  $service_time ?? '',
       
    ];

}
    // print_r($patient_array);
    $data = json_encode($patient_array); // تحويل إلى JSON
$data_encoded = urlencode(base64_encode($data)); // تشفير


    header('Location: paiement_recu.php?list='. $data_encoded);
    exit();

}

?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <meta name="copyright" content="MACode ID, https://macodeid.com/">

  <title>allotabibi</title>

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/css/theme.css">
   <link rel="icon" type="image/png" href="allotabibi.png">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
  <style>
    body {
      background-color: #f8f9fa;
    }
    .card {
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .step {
      display: none;
    }
    .step.active {
      display: block;
    }
  </style>
</head>
<body>
  <header>
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
           <div class="site-info">
              <a href="#"><span class="mai-call text-primary"></span> +213 662 446 446</a>
              <a href="#"><span class="mai-call text-primary"></span> +213 559 230 000</a>
              <span class="divider">|</span>
              <a href="#"><span class="mai-mail text-primary"></span> allotabibi@email.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
            <div class="social-mini-button">
              <a href="https://www.facebook.com/allotabibidomicile"><span class="mai-logo-facebook-f"></span></a>
              <a href="https://www.instagram.com/allo_tabibi/"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">allotabibi</span></a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="about.html">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="doctors.html">Doctors</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="blog.html">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.html">Contact</a>
            </li>
            <li class="nav-item">
              <a class="btn btn-primary ml-lg-3" href="#">Login / Register</a>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>
  

  <div class="container py-5">
    <div class="card p-4 mb-4">
      <h4 class="mb-3 text-center">Formulaire Patient</h4>
      <form id="patientForm" action="pageformClient.php?specialite=<?php echo $specialite ?>&service_time=<?php echo $service_time ?>&service_totale=<?php echo $service_totale ?>" method="post">

        <!-- Étapes -->
        <div class="step active">
          <label for="nom" class="form-label">Nom</label>
          <input type="text" class="form-control mb-3" id="nom" name="nom" required>
          <button type="button" class="btn btn-primary next-btn w-100">Suivant</button>
        </div>

        <div class="step">
          <label for="prenom" class="form-label">Prénom</label>
          <input type="text" class="form-control mb-3" id="prenom" name="prenom" required>
          <button type="button" class="btn btn-primary   next-btn w-100 ">Suivant</button>
        </div>

        <div class="step">
          <label for="tel" class="form-label">Tel</label>
          <input type="tel" class="form-control mb-3" id="tel" name="tel" required>
          <button type="button" class="btn btn-primary   next-btn w-100">Suivant</button>
        </div>

        <div class="step">
          <label for="email" class="form-label">Email</label>
          <input type="email" class="form-control mb-3" id="email" name="email" placeholder="optionnel">
          <button type="button" class="btn btn-primary   next-btn w-100">Suivant</button>
        </div>

        <div class="step">
          <label for="age" class="form-label">Âge</label>
          <input type="number" class="form-control mb-3" id="age" name="age" required>
          <button type="button" class="btn btn-primary   next-btn w-100">Suivant</button>
        </div>
<?php 
if($service_time=='rendevou')
       echo' <div class="step">
          <label for="rendezvous" class="form-label">Date de rendez-vous</label>
          <input type="datetime-local"  class="form-control mb-3" id="rendezvous" name="rendezvous" required>
          <button type="button" class="btn btn-primary   next-btn w-100">Suivant</button>
        </div>';
?>
<div class="step w-100">
  <label class="form-label mb-3">Maladie de diabète ?</label>
  <div class="row">
    <div class="col-6">
      <button type="button" class="btn btn-outline-success w-100" name="diabete" value="oui">Oui</button>
    </div>
    <div class="col-6">
      <button type="button" class="btn btn-outline-danger w-100" name="diabete" value="non">Non</button>
    </div>
  </div>
  <div class="mt-4">
    <button type="button" class="btn btn-primary next-btn w-100">Suivant</button>
  </div>
</div>

<div class="step w-100">
  <label class="form-label mb-3">Maladie de cœur ?</label>
  <div class="row">
    <div class="col-6">
      <button type="button" class="btn btn-outline-success w-100" name="coeur" value="oui">Oui</button>
    </div>
    <div class="col-6">
      <button type="button" class="btn btn-outline-danger w-100" name="coeur" value="non">Non</button>
    </div>
  </div>
  <div class="mt-4">
    <button type="button" class="btn btn-primary next-btn w-100">Suivant</button>
  </div>
</div>

<div class="step w-100">
  <label class="form-label mb-3">Maladie de pression ?</label>
  <div class="row">
    <div class="col-6">
      <button type="button" class="btn btn-outline-success w-100" name="tension" value="oui">Oui</button>
    </div>
    <div class="col-6">
      <button type="button" class="btn btn-outline-danger w-100" name="tension" value="non">Non</button>
    </div>
  </div>
  <div class="mt-4">
    <button type="button" class="btn btn-primary next-btn w-100">Suivant</button>
  </div>
</div>

<div class="step w-100">
  <label class="form-label mb-3">Cancer ?</label>
  <div class="row">
    <div class="col-6">
      <button type="button" class="btn btn-outline-success w-100" name="cancer" value="oui">Oui</button>
    </div>
    <div class="col-6">
      <button type="button" class="btn btn-outline-danger w-100" name="cancer" value="non">Non</button>
    </div>
  </div>
  <div class="mt-4">
    <button type="button" class="btn btn-primary next-btn w-100">Suivant</button>
  </div>
</div>

<div class="step w-100">
  <label class="form-label mb-3">VIH / SIDA ?</label>
  <div class="row">
    <div class="col-6">
      <button type="button" class="btn btn-outline-success w-100" name="sida" value="oui">Oui</button>
    </div>
    <div class="col-6">
      <button type="button" class="btn btn-outline-danger w-100" name="sida" value="non">Non</button>
    </div>
  </div>
  <div class="mt-4">
     <button type="submit" class="btn btn-success w-100">Envoyer</button>
  </div>
</div>





      </form>
    </div>
  </div>

  <script>
  // Select all input buttons

  document.querySelectorAll('.step').forEach(step => {
    const buttons = step.querySelectorAll('button[name]');

    buttons.forEach(button => {
      button.addEventListener('click', function () {
        const groupName = this.getAttribute('name');

        // نحصل على جميع الأزرار التي لها نفس الاسم في هذه الخطوة فقط
        const groupButtons = step.querySelectorAll(`button[name="${groupName}"]`);

        // نزيل التلوين السابق
        groupButtons.forEach(btn => {
          btn.classList.remove('btn-outline-success', 'btn-outline-danger');
        });

        // نضيف التلوين حسب القيمة
        if (this.value === 'oui') {
          this.classList.add('btn-success');
        } else if (this.value === 'non') {
          this.classList.add('btn-danger');
        }
      });
    });
  });


    document.addEventListener('DOMContentLoaded', function () {
      const steps = document.querySelectorAll('.step');
      const nextBtns = document.querySelectorAll('.next-btn');
      let currentStep = 0;

      function showStep(index) {
        steps.forEach((step, i) => {
          step.classList.toggle('active', i === index);
        });
      }

      nextBtns.forEach((btn, i) => {
        btn.addEventListener('click', () => {
          if (currentStep < steps.length - 1) {
            currentStep++;
            showStep(currentStep);
          }
        });
      });

      showStep(currentStep);
    });
  </script>
  <footer class="page-footer">
    <div class="container">
      <div class="row px-md-3">
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>Company</h5>
          <ul class="footer-menu">
            <li><a href="#">About Us</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>More</h5>
          <ul class="footer-menu">
            <li><a href="#">Terms & Condition</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>Our partner</h5>
          <ul class="footer-menu">
            <li><a href="#">One-Fitness</a></li>
            <li><a href="#">One-Drugs</a></li>
            <li><a href="#">One-Live</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>Contact</h5>
          <p class="footer-link mt-2">aic elboni annaba</p> <br>
           <a href="#" class="footer-link">0662 446 446</a><br>
           <a href="#" class="footer-link">0559 230 000</a>
          <a href="#" class="footer-link">allotabibi@gmail.com</a>

          <h5 class="mt-3">Social Media</h5>
          <div class="footer-sosmed mt-3">
            <a href="https://www.facebook.com/allotabibidomicile" target="_blank"><span class="mai-logo-facebook-f"></span></a>
            <a href="https://www.instagram.com/allo_tabibi/" target="_blank"><span class="mai-logo-instagram"></span></a>
          </div>
        </div>
      </div>

      <hr>

      <p id="copyright">Copyright &copy; 2025 <a href="https://allotabibi.com/" target="_blank">allotabibi</a>. All right reserved</p>
    </div>
  </footer>

<script src="../assets/js/jquery-3.5.1.min.js"></script>

<script src="../assets/js/bootstrap.bundle.min.js"></script>

<script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<script src="../assets/vendor/wow/wow.min.js"></script>

<script src="../assets/js/theme.js"></script>
</body>
</html>
