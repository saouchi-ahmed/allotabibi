

<?php 
$id_medsin = $_GET['id_medsin']; 


?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Formulaire de Consultation Médicale</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="mb-4">🩺 Consultation Médicale</h2>
    <form action="backend_formulaire_teleconsulation.php?id_medsin=<?=$id_medsin?>" method="POST" class="p-4 border rounded bg-white shadow-sm">
        <div class="mb-3">
            <label for="duree" class="form-label">Durée de la consultation</label>
            <input type="text" class="form-control" id="duree" name="duree">
        </div>

        <div class="mb-3">
            <label for="diagnostic" class="form-label">Diagnostic</label>
            <textarea class="form-control" id="diagnostic" name="diagnostic" rows="3"></textarea>
        </div>

        <div class="mb-3">
            <label for="traitement" class="form-label">Traitement</label>
            <textarea class="form-control" id="traitement" name="traitement" rows="3"></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Examens complémentaires demandés :</label>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="examens[]" value="Bilan biologique" id="bilan">
                <label class="form-check-label" for="bilan">Bilan biologique</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="examens[]" value="Imagerie médicale" id="imagerie">
                <label class="form-check-label" for="imagerie">Imagerie médicale</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="examens[]" value="Perfusion" id="perfusion">
                <label class="form-check-label" for="perfusion">Perfusion</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="examens[]" value="Avis spécialisé" id="avis">
                <label class="form-check-label" for="avis">Avis spécialisé</label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="examens[]" value="Orientation vers les urgences" id="urgence">
                <label class="form-check-label" for="urgence">Orientation vers les urgences</label>
            </div>
        </div>

        <div class="mb-3">
            <label for="rendezvous" class="form-label">Rendez-vous de suivi</label>
            <input type="text" class="form-control" id="rendezvous" name="rendezvous">
        </div>

        <button type="submit" class="btn btn-primary">Enregistrer</button>
    </form>
</div>
</body>
</html>
