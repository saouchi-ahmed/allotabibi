<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Connexion à la base de données
include 'config.php';
if ($conn->connect_error) {
    die("Échec de la connexion à la base de données : " . $conn->connect_error);
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    
if($_POST['username']=="admin"&&$_POST['password']=="0000"){
    $_SESSION['username'] = "admin";
    header("Location: gestionMedsin.php"); // Redirige vers une page d'accueil

}
    $username = $_POST['username'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT * FROM medsins WHERE user_name = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();

    $result = $stmt->get_result();
    
    if ($result->num_rows >=1) {
        $row = $result->fetch_assoc();
        $_SESSION['username'] = $username;
        $_SESSION['id_medsin']= $row['id'];
        
        header("Location: dahbord.php"); // Redirige vers une page d'accueil
        exit();
    } else {
        $error = "Nom d'utilisateur ou mot de passe incorrect.";
     // echo $password.'  '.$username. ' '.$result->num_rows ;
    }
    

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Connexion</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center vh-100">

<div class="card shadow p-4" style="width: 100%; max-width: 400px;">
    <h2 class="text-center mb-4">Connexion</h2>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger text-center"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="mb-3">
            <label for="username" class="form-label">Nom d'utilisateur</label>
            <input type="text" class="form-control" name="username" id="username" required>
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Mot de passe</label>
            <input type="password" class="form-control" name="password" id="password" required>
        </div>

        <button type="submit" class="btn btn-primary w-100">Se connecter</button>
    </form>
</div>

<!-- Bootstrap JS (optionnel pour certains composants) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
