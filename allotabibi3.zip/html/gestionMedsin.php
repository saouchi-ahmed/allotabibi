<?php

// maktaba lifah les fnct ti3i 
include 'saouchi_skander_inputs_from_library.php';
// configuration ta3 bd 
$conn = config_db("allotabibi2");
// ism la table fi bd 
$table = "medsins2";
// list faha les name ta3 les colone ta3 tableau w tani homa ba3d les name ta3 les input 
$fields = [
    'nom', 'prenom', 'age', 'tel', 'adresse', 'email', 'specialiste',
    'disponible_tleconsultation', 'user_name', 'password', 'dis_midiatemant_tel',
    'heur_travaille_teleconsultation', 'disponible_adomisil', 'midiatemant_admiicle',
      'annee_diplome', 'ville_travaille',
      'travaille_public_ou_prive','photo','ccp'
];

  // إدارة POST و DELETE
  // code fih gestion ta3 post kamla yista3mil fi list lifah name limditha fog
$edit = post_f($conn, $table, $fields, 'gestionMedsin.php');

//print_r($edit);
//print_r($edit);

// === بيانات الحقول الخاصة بالاختيارات
$specialites = [
    "medecine_generale" => "Médecine Générale",
    "pediatrie" => "Pédiatrie",
    "cardiologie" => "Cardiologie",
    "dermatologie" => "Dermatologie",
    "ophtalmologie" => "Ophtalmologie",
    "gynecologie" => "Gynécologie et Obstétrique",
    "neurologie" => "Neurologie",
    "oncologie" => "Oncologie",
    "orthopedie" => "Orthopédie",
    "radiologie" => "Radiologie",
    "psychiatrie" => "Psychiatrie",
    "chirurgie_generale" => "Chirurgie Générale"
];
// list ta3 i5tiyarat oui ou no
$oui_non = ["oui" => "Oui", "no" => "Non"];
// list ta3 i5tiyarat public ou prive
$public_prive = ["public" => "public", "prive" => "prive"];
// list ta3 i5tiyarat faha les heurs de travaille
$heures = [
'8:00-14:00',
'12:00-17:00',
'16:00-21:00',
'19:00-00:00'
];
$heures2 = [
'00:00',
'01:00',
'02:00',
'03:00',
'04:00',
'05:00',
'06:00',
'07:00',
'08:00',
'09:00',
'10:00',
'11:00',
'12:00',
'13:00',
'14:00',
'15:00',
'16:00',
'17:00',
'18:00',
'19:00',
'20:00',
'21:00',
'22:00',
'23:00'
];
// === نموذج الإدخال
// dorka ga3d ncriyi fi form fi $ text_html 
$text_html = "";
$text_html .= champ("nom", "Nom");
$text_html .= champ("prenom", "Prénom");
$text_html .= champ("age", "Âge", "number");
$text_html .= champ("tel", "Téléphone");
$text_html .= champ("adresse", "Adresse");
$text_html .= champ("email", "Email", "email");
$text_html .= select_one_options("specialiste", "Spécialité", $specialites,'Sélectionnez une spécialité');
$text_html .= champ("ccp", "ccp");
$text_html .='<br><hr>';
$text_html .= champ("user_name", "Nom d'utilisateur");
$text_html .= champ("password", "Mot de passe", );
$text_html .='<br><hr>';
$text_html .= checbox("disponible_tleconsultation",  "Disponible pour téléconsultation ?", $oui_non);
$text_html .= checbox("dis_midiatemant_tel", "Téléconsultation immédiate ?", $oui_non);
$text_html .= select_multy_chacbox("heur_travaille_teleconsultation", "Heures de travail teleconsultation", array_combine($heures2, $heures2));
$text_html .='<br><hr>';
$text_html .= checbox("disponible_adomisil", "Disponible à domicile ?", $oui_non);
$text_html .= checbox("midiatemant_admiicle", "Consultation immédiate à domicile ?", $oui_non);
$text_html .='<br><hr><h1 class="text-center">Cv</h1>';
$text_html .= champ("annee_diplome", "Année d’obtention de diplôme ");
$text_html .= champ("ville_travaille", "Cité du travail ");
$text_html .='<h1> </h1>';
$text_html .= select_one_options("travaille_public_ou_prive", "Travailler dans le secteur public ou privé ", $public_prive,'Sélectionnez');
$text_html .=upload_photo("photo", "upload photo");
$text_html .='<h1> </h1>';



// === عرض الأطباء في جدول (اختياري)
// adi tjib listfaha toba kol 
$meds = select_all_data($conn, $table);
// fih code html ta3 head kamil bih bi les link bootstrap jqury 
$text_html_head= head_html('gestionMedsin');
//hada code html ta3 form yit7at $text_html_body_form
$text_html_body_form=form_body($text_html, "id");
//hada code html ta3 tableau yit7at $text_html_body_table
$text_html_body_table=afficherTableau($meds); 





// code javascript
$js_text='
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function() {
        $(\'#myTable\').DataTable({
            language: {
                url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/fr.json"
            }
        });
    });
</script>
';
// hada ykawn code ta3 body 
$text_html_body= body_html($text_html_body_form.$text_html_body_table,$js_text);
// hada ykawn code ta3 page ta3 page html kamla 
code_html($text_html_head.$text_html_body);
?>