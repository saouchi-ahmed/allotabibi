<!-- feedback.php -->


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="UTF-8">
  <title>Évaluation Téléconsultation</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center" style="height:100vh;">

<div class="card shadow p-4" style="max-width: 500px; width: 100%;">
  <h4 class="mb-3 text-center">Donnez votre avis</h4>
  <form action="save_feedback.php" method="POST">
    
<div class="mb-3 text-center">
  <label class="form-label mb-3">Votre satisfaction :</label>
  <div class="d-flex justify-content-center gap-3 flex-wrap">

    <!-- Card 1 -->
    <div class="card p-3" style="min-width: 150px;">
      <div class="form-check">
        <input class="form-check-input" type="radio" name="satisfaction" id="option1" value="Très satisfait" required>
        <label class="form-check-label" for="option1">👍 Très satisfait</label>
      </div>
    </div>

    <!-- Card 2 -->
    <div class="card p-3" style="min-width: 150px;">
      <div class="form-check">
        <input class="form-check-input" type="radio" name="satisfaction" id="option2" value="Assez satisfait">
        <label class="form-check-label" for="option2">👌 Assez satisfait</label>
      </div>
    </div>

    <!-- Card 3 -->
    <div class="card p-3" style="min-width: 150px;">
      <div class="form-check">
        <input class="form-check-input" type="radio" name="satisfaction" id="option3" value="Pas satisfait">
        <label class="form-check-label" for="option3">👎 Pas satisfait</label>
      </div>
    </div>

  </div>
</div>


    <div class="mb-3">
      <label for="note" class="form-label">Votre message (optionnel)</label>
      <textarea class="form-control" id="note" name="note" rows="3" placeholder="Écrivez un commentaire..."></textarea>
    </div>

    <button type="submit" class="btn btn-primary w-100">Envoyer</button>
  </form>
</div>

</body>
</html>
