<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Choisir un service</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .service-card {
            transition: transform 0.2s ease-in-out;
            cursor: pointer;
        }
        .service-card:hover {
            transform: scale(1.03);
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <h2 class="text-center mb-4">Choisissez un table</h2>
        <div class="row justify-content-center g-4">
            <!-- Service 1 -->
            <div class="col-md-6">
                <div class="card service-card shadow-sm" onclick="window.location.href='admin_medsin_adomicile/reservations.php'">
                    <div class="card-body text-center">
                        <h4 class="card-title">👨‍⚕️les Réservations de médecin à domicile</h4>
                        <p class="card-text text-muted">Recevez un médecin chez vous à l'heure qui vous convient.</p>
                    </div>
                </div>
            </div>

            <!-- Service 2 -->
            <div class="col-md-6">
                <div class="card service-card shadow-sm" onclick="window.location.href='admin_teleconsultation/reservations.php'">
                    <div class="card-body text-center">
                        <h4 class="card-title">📲les Réservations de téléconsultation</h4>
                        <p class="card-text text-muted">Consultez un médecin en ligne via appel vidéo sécurisé.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
