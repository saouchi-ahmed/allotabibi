<?php

// maktaba lifah les fnct ti3i 
include 'saouchi_skander_inputs_from_library.php';
// configuration ta3 bd 
$conn = config_db("allotabibi2");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $duree = $_POST['duree'];
    $diagnostic = $_POST['diagnostic'];
    $traitement = $_POST['traitement'];
    $examens = isset($_POST['examens']) ? implode(", ", $_POST['examens']) : "Aucun";
    $rendezvous = $_POST['rendezvous'];
     $id_medsin = $_GET['id_medsin']; 
    echo "<h2>📝 Résumé de la consultation</h2>";
    echo "<p><strong>Durée :</strong> $duree</p>";
    echo "<p><strong>Diagnostic :</strong> $diagnostic</p>";
    echo "<p><strong>Traitement :</strong> $traitement</p>";
    echo "<p><strong>Examens demandés :</strong> $examens</p>";
    echo "<p><strong>Rendez-vous :</strong> $rendezvous</p>";

   
    $conn->update("reservation_client", [
    "duree" => $duree,
     "diagnostic" => $diagnostic,
      "traitement" => $traitement,
       "examens_demandes" => $examen,
        "rendez_vous" =>  $rendezvous
], [
    "id" =>  $id_medsin
]);

}
?>
