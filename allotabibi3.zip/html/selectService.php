<?php 
$service_totale=$_GET['service_totale'];
if($service_totale=='teleconsultation'){
$text1=' Réservez votre  téléconsultation immédiatement';
$text2=' Réservez votre rendez-vous de téléconsultation ';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <meta name="copyright" content="MACode ID, https://macodeid.com/">

  <title>allotabibi</title>

  <link rel="stylesheet" href="../assets/css/maicons.css">

  <link rel="stylesheet" href="../assets/css/bootstrap.css">

  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">

  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">

  <link rel="stylesheet" href="../assets/css/theme.css">
   <link rel="icon" type="image/png" href="allotabibi.png">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body>
<style>
    
        @keyframes takbirtas8ir {
            0%{
                transform: scale(1);
              }
            50%{
                transform: scale(1.05);
              } 
            100%{
                transform: scale(1);
              } 
        }
            .service-card {
            transition: transform 0.2s ease-in-out;
            cursor: pointer;
            animation: takbirtas8ir 3s infinite ;
        }
        .service-card:hover {
            transform: scale(1.03);
        }

        
</style>
  <!-- Back to top button -->
  <div class="back-to-top"></div>

  <header>
    <div class="topbar">
      <div class="container">
        <div class="row">
          <div class="col-sm-8 text-sm">
           <div class="site-info">
              <a href="#"><span class="mai-call text-primary"></span> +213 662 446 446</a>
              <a href="#"><span class="mai-call text-primary"></span> +213 559 230 000</a>
              <span class="divider">|</span>
              <a href="#"><span class="mai-mail text-primary"></span> allotabibi@email.com</a>
            </div>
          </div>
          <div class="col-sm-4 text-right text-sm">
            <div class="social-mini-button">
              <a href="https://www.facebook.com/allotabibidomicile"><span class="mai-logo-facebook-f"></span></a>
              <a href="https://www.instagram.com/allo_tabibi/"><span class="mai-logo-instagram"></span></a>
            </div>
          </div>
        </div> <!-- .row -->
      </div> <!-- .container -->
    </div> <!-- .topbar -->

    <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
      <div class="container">
        <a class="navbar-brand" href="#"><span class="text-primary">allotabibi</span></a>
        
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport" aria-controls="navbarSupport" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupport">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="about.html">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="doctors.html">Doctors</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="blog.html">News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.html">Contact</a>
            </li>
            <li class="nav-item">
              <a class="btn btn-primary ml-lg-3" href="#">Login / Register</a>
            </li>
          </ul>
        </div> <!-- .navbar-collapse -->
      </div> <!-- .container -->
    </nav>
  </header>

  <div class="page-banner overlay-dark bg-image" style="background-image: url(../assets/img/bg_image_1.jpg);">
    <div class="banner-section">
      <div class="container text-center wow fadeInUp">
        <nav aria-label="Breadcrumb">
          <ol class="breadcrumb breadcrumb-dark bg-transparent justify-content-center py-0 mb-2">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About</li>
          </ol>
        </nav>
        <h1 class="font-weight-normal">select service</h1>
      </div> <!-- .container -->
    </div> <!-- .banner-section -->
  </div> <!-- .page-banner -->

            </div>
 </div>
    </div>
  </div>
</div>


<div class="bg-light">
  <div class="page-section py-3 mt-md-n5 custom-index">
    <div class="container">
      <div class="row justify-content-center">


        <div class="col-md-4 py-3 py-md-0 " >
            
          <div class="w-100 card-service wow fadeInUp service-card  " onclick=  "window.location.href='selectspecialite.php?service_time=immédiatement&service_totale=<?=$service_totale?>'  ">
            <div class="circle-shape bg-success text-white">
              <i class="fas fa-notes-medical"></i>
            </div>
            <p ><?= $text1 ?></p>
          </div>
        </div>

        <div class="col-md-4 py-3 py-md-0">
          <div class="w-100 card-service wow fadeInUp service-card " onclick=  "window.location.href='selectspecialite.php?service_time=rendevou&service_totale=<?=$service_totale?>'  ">
            <div class="circle-shape bg-danger text-white">
              <i class="fas fa-video"></i>
            </div>
            <p><?= $text2 ?></p>
          </div>
        </div>



      
      </div>
    </div>
  </div>
</div>



<br><br><br><br><br><br><br><br><br>

    </div>
  </div>

  <div class="page-section banner-home bg-image" style="background-image: url(../assets/img/banner-pattern.svg);">
    <div class="container py-5 py-lg-0">
      <div class="row align-items-center">
        <div class="col-lg-4 wow zoomIn">
        </div>
      </div>
    </div>
  </div> <!-- .banner-home -->

  <footer class="page-footer">
    <div class="container">
      <div class="row px-md-3">
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>Company</h5>
          <ul class="footer-menu">
            <li><a href="#">About Us</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>More</h5>
          <ul class="footer-menu">
            <li><a href="#">Terms & Condition</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>Our partner</h5>
          <ul class="footer-menu">
            <li><a href="#">One-Fitness</a></li>
            <li><a href="#">One-Drugs</a></li>
            <li><a href="#">One-Live</a></li>
          </ul>
        </div>
        <div class="col-sm-6 col-lg-3 py-3">
          <h5>Contact</h5>
          <p class="footer-link mt-2">aic elboni annaba</p> <br>
           <a href="#" class="footer-link">0662 446 446</a><br>
           <a href="#" class="footer-link">0559 230 000</a>
          <a href="#" class="footer-link">allotabibi@gmail.com</a>

          <h5 class="mt-3">Social Media</h5>
          <div class="footer-sosmed mt-3">
            <a href="https://www.facebook.com/allotabibidomicile" target="_blank"><span class="mai-logo-facebook-f"></span></a>
            <a href="https://www.instagram.com/allo_tabibi/" target="_blank"><span class="mai-logo-instagram"></span></a>
          </div>
        </div>
      </div>

      <hr>

      <p id="copyright">Copyright &copy; 2025 <a href="https://allotabibi.com/" target="_blank">allotabibi</a>. All right reserved</p>
    </div>
  </footer>

<script src="../assets/js/jquery-3.5.1.min.js"></script>

<script src="../assets/js/bootstrap.bundle.min.js"></script>

<script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>

<script src="../assets/vendor/wow/wow.min.js"></script>

<script src="../assets/js/theme.js"></script>
  
</body>
</html>