
<?php 

session_start(); 

$service_time = $_GET['service_time'];
$service_totale= $_GET['service_totale'];
include 'config.php';

$specialitesMedecins = array(
     "Médecine générale",
    "Cardiologie",
    "Dermatologie",
    "pediatrie",
    "Neurologie",
    "Gynécologie",
    "Orthopédie",
    "Ophtalmologie",
    "Radiologie",
    "Chirurgie générale",
    "Psychiatrie",
    "Anesthésiologie",
    "Endocrinologie",
    "Gastro-entérologie",
    "Néphrologie",
    "Oncologie",
    "Rhumatologie",
    "Urologie",
    "Oto-rhino-laryngologie (ORL)",
    "Médecine interne"
);
$specialites = [
    "medecine_generale" => "Médecine Générale",
    "pediatrie" => "Pédiatrie",
    "cardiologie" => "Cardiologie",
    "dermatologie" => "Dermatologie",
    "ophtalmologie" => "Ophtalmologie",
    "gynecologie" => "Gynécologie et Obstétrique",
    "neurologie" => "Neurologie",
    "oncologie" => "Oncologie",
    "orthopedie" => "Orthopédie",
    "radiologie" => "Radiologie",
    "psychiatrie" => "Psychiatrie",
    "chirurgie_generale" => "Chirurgie Générale"
];
if($service_time=='rendevou'){
    $stmt = $conn->prepare("SELECT specialiste FROM medsins2 WHERE 	disponible_tleconsultation='oui'");
    $stmt->execute();
    $result = $stmt->get_result();
    $result_array=array();
    while( $row= $result->fetch_assoc()){
        
        $result_array[]=$row['specialiste'];
    }
}else
{
      $stmt = $conn->prepare("SELECT specialiste FROM medsins2 WHERE 	disponible_tleconsultation='oui'and dis_midiatemant_tel='oui'");
    $stmt->execute();
    $result = $stmt->get_result();
    $result_array=array();
    while( $row= $result->fetch_assoc()){
        
        $result_array[]=$row['specialiste'];
    }
          $stmt = $conn->prepare("SELECT specialiste FROM medsins2 ");
    $stmt->execute();
    $result_all_medsin_with_all_info = $stmt->get_result();
    $result_all_medsin_speciality=array();
    while( $row= $result_all_medsin_with_all_info->fetch_assoc()){
        
        $result_all_medsin_speciality[]=$row['specialiste'];
    }
}





    
  /*
   echo'<pre>';
    print_r($result_array);
   echo'</pre>';
 */
 
$array_clean=array();
 foreach (array_keys($specialites) as $key_specialite){
     
     if(in_array($key_specialite,$result_array)){
         
         $array_clean[]=$specialites[$key_specialite];
     }
 }

 $specialites = array_diff($specialites, $array_clean);
/*
    echo'<pre>d';
    print_r( $specialites );
   echo'</pre>';
 */
 
$oui=0;



     

?>


<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta name="copyright" content="MACode ID, https://macodeid.com/">
  <title>allotabibi</title>

  <link rel="icon" type="image/png" href="allotabibi.png">
  <link rel="stylesheet" href="../assets/css/maicons.css">
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <link rel="stylesheet" href="../assets/vendor/owl-carousel/css/owl.carousel.css">
  <link rel="stylesheet" href="../assets/vendor/animate/animate.css">
  <link rel="stylesheet" href="../assets/css/theme.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

  <style>


    .service-card {
      transition: transform 0.3s ease-in-out;
      cursor: pointer;
    }

    .service-card:hover {
      transform: scale(1.05);
    }

    .card-disabled {
      background-color: #dee2e6 !important;
      cursor: not-allowed !important;
      color: #6c757d !important;
    }

    .card-title {
      font-size: 1.2rem;
      font-weight: 600;
    }

    .card-body {
      min-height: 100px;
    }

    .page-banner {
      background-size: cover;
      background-position: center;
    }
  </style>
</head>
<body>

<!-- Back to top -->
<div class="back-to-top"></div>

<!-- Header -->
<header>
  <div class="topbar">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 text-sm">
          <div class="site-info">
            <a href="#"><span class="mai-call text-primary"></span> +213 662 446 446</a>
            <a href="#"><span class="mai-call text-primary"></span> +213 559 230 000</a>
            <span class="divider">|</span>
            <a href="#"><span class="mai-mail text-primary"></span> allotabibi@email.com</a>
          </div>
        </div>
        <div class="col-sm-4 text-right text-sm">
          <div class="social-mini-button">
            <a href="https://www.facebook.com/allotabibidomicile"><span class="mai-logo-facebook-f"></span></a>
            <a href="https://www.instagram.com/allo_tabibi/"><span class="mai-logo-instagram"></span></a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <nav class="navbar navbar-expand-lg navbar-light shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="#"><span class="text-primary">allotabibi</span></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupport">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupport">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a class="nav-link" href="index.html">Home</a></li>
          <li class="nav-item active"><a class="nav-link" href="about.html">About Us</a></li>
          <li class="nav-item"><a class="nav-link" href="doctors.html">Doctors</a></li>
          <li class="nav-item"><a class="nav-link" href="blog.html">News</a></li>
          <li class="nav-item"><a class="nav-link" href="contact.html">Contact</a></li>
          <li class="nav-item"><a class="btn btn-primary ml-lg-3" href="#">Login / Register</a></li>
        </ul>
      </div>
    </div>
  </nav>
</header>

<!-- Banner -->
<div class="page-banner overlay-dark bg-image" style="background-image: url(../assets/img/bg_image_1.jpg);">
  <div class="banner-section">
    <div class="container text-center wow fadeInUp">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-dark bg-transparent justify-content-center py-0 mb-2">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">About</li>
        </ol>
      </nav>
      <h1 class="font-weight-normal">Choisissez une spécialité</h1>
    </div>
  </div>
</div>

<!-- Section Spécialités -->
<div class="container py-5">
  <h2 class="mb-5 text-center">Spécialités des Médecins</h2>

  <?php if (count($array_clean) > 0): ?>
    <div class="row">
            <?php foreach ($array_clean as $array_clean_element): ?>
        <?php //$oui = in_array($specialite, $array_clean); ?>
        <div class="col-md-4 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex align-items-center justify-content-center service-card "
               
         
                onclick="window.location.href='pageformClient.php?specialite=<?= urlencode($array_clean_element) ?>&service_time=<?= $service_time ?>&service_totale=<?= $service_totale ?>'"
        
            >
              <h5 class="card-title text-center"><?= htmlspecialchars($array_clean_element) ?></h5>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      <?php foreach ($specialites as $specialite): ?>

        <div class="col-md-4 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-body d-flex flex-column  align-items-center justify-content-center  card-disabled  ">
              <h5 class="card-title text-center"><?= htmlspecialchars($specialite) ?></h5>
    <?php 
$key_speciality = array_search($specialite, $specialites);

if($service_time!='rendevou'){
if(in_array($key_speciality, $result_all_medsin_speciality)){
  echo '<a href="selectService.php?service_totale=teleconsultation" class="d-block text-center">disponible en rendez-vous</a>';
}
}

?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="alert alert-warning text-center" role="alert">
      Aucun médecin trouvé pour ce critère.
    </div>
  <?php endif; ?>
</div>

<!-- Footer -->
<footer class="page-footer">
  <div class="container">
    <div class="row px-md-3">
      <div class="col-sm-6 col-lg-3 py-3">
        <h5>Company</h5>
        <ul class="footer-menu">
          <li><a href="#">About Us</a></li>
        </ul>
      </div>
      <div class="col-sm-6 col-lg-3 py-3">
        <h5>More</h5>
        <ul class="footer-menu">
          <li><a href="#">Terms & Condition</a></li>
        </ul>
      </div>
      <div class="col-sm-6 col-lg-3 py-3">
        <h5>Our partner</h5>
        <ul class="footer-menu">
          <li><a href="#">One-Fitness</a></li>
          <li><a href="#">One-Drugs</a></li>
          <li><a href="#">One-Live</a></li>
        </ul>
      </div>
      <div class="col-sm-6 col-lg-3 py-3">
        <h5>Contact</h5>
        <p class="footer-link mt-2">aic elboni annaba</p>
        <a href="#" class="footer-link">0662 446 446</a><br>
        <a href="#" class="footer-link">0559 230 000</a><br>
        <a href="#" class="footer-link">allotabibi@gmail.com</a>
        <h5 class="mt-3">Social Media</h5>
        <div class="footer-sosmed mt-3">
          <a href="https://www.facebook.com/allotabibidomicile" target="_blank"><span class="mai-logo-facebook-f"></span></a>
          <a href="https://www.instagram.com/allo_tabibi/" target="_blank"><span class="mai-logo-instagram"></span></a>
        </div>
      </div>
    </div>

    <hr>
    <p id="copyright">Copyright &copy; 2025 <a href="https://allotabibi.com/" target="_blank">allotabibi</a>. All rights reserved</p>
  </div>
</footer>

<!-- Scripts -->
<script src="../assets/js/jquery-3.5.1.min.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/vendor/owl-carousel/js/owl.carousel.min.js"></script>
<script src="../assets/vendor/wow/wow.min.js"></script>
<script src="../assets/js/theme.js"></script>

</body>
</html>
