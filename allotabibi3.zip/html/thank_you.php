<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>شكراً لك!</title>
</head>
<body>
    <h1>✅ تم الدفع بنجاح</h1>
    <p>شكراً لك على الدفع. سنتواصل معك قريباً.</p>
</body>
</html>
