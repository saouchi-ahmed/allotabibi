<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
//echo $_SESSION['id_medsin'];
include '../config.php';
if ($conn->connect_error) {
    die("Échec de connexion : " . $conn->connect_error);
}

$id_medsin=$_SESSION['id_medsin'];
$sql = "SELECT r.full_name_client, r.tel_client, r.adresse,r.link_api ,r.date_heure, m.nom, m.prenom
        FROM tendevous_teleconsultation r
        JOIN medsins m ON r.id_medsin = m.id
        WHERE r.id_medsin = $id_medsin
        ORDER BY r.`date_heure` ASC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['full_name_client']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tel_client']) . "</td>";
        echo "<td>" . htmlspecialchars($row['adresse']) . "</td>";
        echo "<td>" . htmlspecialchars($row['date_heure']) . "</td>";
        echo "<td>Dr. " . htmlspecialchars($row['nom']) . " " . htmlspecialchars($row['prenom']) . "</td>";
       
        echo '<td> <a href="'.$row['link_api'].'">rejoindre appel vidéo</a> ' . htmlspecialchars($row["link_api"]) . '</td>';
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='5' class='text-center text-muted'>Aucune réservation trouvée.</td></tr>";
}
$conn->close();
?>
