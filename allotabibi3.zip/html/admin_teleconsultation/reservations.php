<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Réservations</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .table-responsive { max-height: 500px; overflow-y: auto; }
    </style>
</head>
<body class="bg-light">
<div class="container py-4">
    <h2 class="mb-4 text-center">📋 Liste des Réservations</h2>
    
    <div id="reservationsContainer" class="table-responsive">
        <table class="table table-bordered table-hover bg-white">
            <thead class="table-dark">
                <tr>
                    <th>Nom du Client</th>
                    <th>Téléphone</th>
                    <th>Adresse</th>
                    <th>Date & Heure</th>
                    <th>Médecin</th>
                    <th>link d'appel</th>
                </tr>
            </thead>
            <tbody id="reservationsBody">
                <!-- Les données seront chargées ici via AJAX -->
            </tbody>
        </table>
    </div>
</div>

<script>
// Fonction pour charger les données de réservation
function loadReservations() {
    fetch('get_reservations.php')
        .then(response => response.text())
        .then(data => {
            document.getElementById('reservationsBody').innerHTML = data;
        });
}

// Charger les données immédiatement et toutes les 10 secondes
loadReservations();
setInterval(loadReservations, 1000); // 1 secondes
</script>
</body>
</html>
