<?php
// تضمين المكتبة الخاصة بالمشروع
include 'saouchi_skander_inputs_from_library.php';

// فك تشفير البيانات القادمة من GET
$data_encoded = $_GET['list'];
$json = base64_decode($data_encoded);
$data_list = json_decode($json, true);

// قائمة التخصصات
$specialites = [
    "medecine_generale" => "Médecine Générale",
    "pediatrie" => "Pédiatrie",
    "cardiologie" => "Cardiologie",
    "dermatologie" => "Dermatologie",
    "ophtalmologie" => "Ophtalmologie",
    "gynecologie" => "Gynécologie et Obstétrique",
    "neurologie" => "Neurologie",
    "oncologie" => "Oncologie",
    "orthopedie" => "Orthopédie",
    "radiologie" => "Radiologie",
    "psychiatrie" => "Psychiatrie",
    "chirurgie_generale" => "Chirurgie Générale"
];

// الاتصال بقاعدة البيانات
$db = config_db('allotabibi2');

// جلب جميع الأطباء
$all_medsins = select_all_data($db, 'medsins2');

// قائمة الأطباء المتاحين بعد التصفية
$all_medsins_clean = [];

// تصفية الأطباء حسب نوع الخدمة والتخصص
if($data_list['service_totale']=='teleconsultation'){

    // نجيب المفتاح (key) الخاص بالتخصص
    $specialite_key = array_search($data_list['specialite'], $specialites);

    if ($specialite_key !== false) {
        foreach ($all_medsins as $medsin) {
            $match_specialite = $medsin['specialiste'] === $specialite_key;
            $available_now = isNowInTimeList($medsin['heur_travaille_teleconsultation']);

            if ($data_list['service_time'] == 'rendevou') {
                if ($match_specialite && $medsin['disponible_tleconsultation'] == 'oui' && $available_now) {
                    $all_medsins_clean[] = $medsin;
                }
            }

            if ($data_list['service_time'] == 'immédiatement') {
                if ($match_specialite && $medsin['disponible_tleconsultation'] == 'oui' && $medsin['dis_midiatemant_tel'] == 'oui' && $available_now) {
                    $all_medsins_clean[] = $medsin;
                }
            }
        }
    } else {
        echo "❌ التخصص غير موجود في القائمة.";
    }
}

// نحدد إذا الطبيب المتاح حالياً في الوقت المناسب (لأول طبيب فقط)
$in_time = false;
if (count($all_medsins_clean) > 0) {
    $in_time = isNowInTimeList($all_medsins_clean[0]['heur_travaille_teleconsultation']);
}

// السعر
$prix = 1000;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reçu de paiement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .unavailable-card {
            background-color: #f0f0f0;
            opacity: 0.6;
            cursor: not-allowed;
            border: 1px solid #ccc;
        }
    .error {
      color: red;
      display: none;
    }
    </style>
</head>
<body>
<div class="container py-5">
    <?php
    if (count($all_medsins_clean) == 0) {
        echo "<div class='alert alert-danger' role='alert'>
            Désolé, aucun médecin en " . htmlspecialchars($data_list['specialite']) . " n'est disponible pour le moment.
        </div>";
    }
    ?>

    <div class="card p-4 <?= !$in_time ? "unavailable-card text-muted" : "" ?>">
        <h3 class="mb-4 text-center">Reçu de paiement</h3>
        <p><strong>Nom :</strong> <?= htmlspecialchars($data_list['nom']) ?></p>
        <p><strong>Prénom :</strong> <?= htmlspecialchars($data_list['prenom']) ?></p>
        <p><strong>Téléphone :</strong> <?= htmlspecialchars($data_list['tel']) ?></p>
        <p><strong>Email :</strong> <?= htmlspecialchars($data_list['email']) ?></p>
        <p><strong>Âge :</strong> <?= htmlspecialchars($data_list['age']) ?></p>
        <p><strong>Date de rendez-vous :</strong> <?= htmlspecialchars($data_list['rendezvous']) ?></p>
        <hr>
        <p><strong>Service :</strong> <?= htmlspecialchars($data_list['service_totale']) ?> | <?= htmlspecialchars($data_list['service_time']) ?></p>
        <p><strong>Spécialité :</strong> <?= htmlspecialchars($data_list['specialite']) ?></p>
        <p><strong>Prix :</strong> <?= $prix ?> DZD</p>
        <strong class="text-center">Médecins disponibles :</strong>

        <div style="height:3cm; overflow-y: auto;">
        <form action="checkout.php?list=<?= htmlspecialchars($data_encoded) ?>" method="POST"  onsubmit="return checkAgreement()" >
            <?php  
  

if (count($all_medsins_clean) >= 1){
echo '

    <table class="table table-bordered text-center">
        <thead>
            <tr>
            <th>Sélection</th>
            <th>Nom et Prénom</th>
            <th>Âge</th>
             <th> CV</th>  
            </tr>
        </thead>
        <tbody>
          ';
           foreach ($all_medsins_clean as $index => $medsin){
                $modal_id = "medModal_" . $index;
            echo'
            <tr>
                <td>
                    <input type="radio" name="selected_medsin_id" value="'. htmlspecialchars($medsin['id']) .'" required>
                </td>
                <td>
                    Dr : '. htmlspecialchars($medsin['nom']) .' '. htmlspecialchars($medsin['prenom']).'
                </td>
                <td>
                    '.htmlspecialchars($medsin['age']) .' ans
                </td>
                <td>
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#'.$modal_id.'">
                        CV
                    </button>
                </td>
            </tr>

            <!-- Modal -->
            <div class="modal fade" id="'.$modal_id.'" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="'.$modal_id.'Label" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="<?= $modal_id ?>Label">CV du médecin</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center">
                                <img src="uploads/'. htmlspecialchars($medsin['photo']) .'" alt="" class="img-thumbnail" style="max-width: 150px;">
                            </div><br>
                            <label><b>Nom complet</b>: Dr '. htmlspecialchars($medsin['nom']) .' '. htmlspecialchars($medsin['prenom']) .'</label><br>
                            <label><b>Âge</b>: '. htmlspecialchars($medsin['age']) .'</label><br>
                            <label><b>Année de diplôme</b>: '. htmlspecialchars($medsin['annee_diplome']) .'</label><br>
                            <label><b>Spécialité</b>: '. htmlspecialchars($medsin['specialiste']) .'</label><br>
                            <label><b>Ville de travail</b>: '. htmlspecialchars($medsin['ville_travaille']) .'</label><br>
                            <label><b>Secteur de travail (public/privé)</b>: '. htmlspecialchars($medsin['travaille_public_ou_prive']) .'</label><br>
                        </div>
                        <div class="modal-footer">
                        </div>
                    </div>
                </div>
            </div>';
           }
           echo '
        </tbody>
    </table>';
            }
            
            ?>
        </div>
        <hr>

       
    <label>
      <input type="checkbox" id="agree">
     J'accepte<a href="conditions_d_utilisation.html" > les conditions générales d'utilisation allotabibi</a> 
    </label>
    <br>
        <label>
      <input type="checkbox" id="agree2">
     J'accepte<a href="politique_confidentialite.html" > Politique de Confidentialité allo tabibi</a> 
    </label>
    <br>
    <br>
    <p class="error text-center" id="error-msg">Vous devez accepter les conditions et politique de confidentialité avant de soumettre la demande.</p>

        <button type="submit" class="btn btn-success <?= !$in_time ? "disabled" : "" ?>" <?= !$in_time ? 'tabindex="-1" aria-disabled="true"' : '' ?> >Payer pour prendre le service</button>
    
    </form>
   </div>
</div>
  <script>
function checkAgreement() {
  var checkbox = document.getElementById("agree");
  var checkbox2 = document.getElementById("agree2");
  var errorMsg = document.getElementById("error-msg");
  //alert('1'+checkbox.checked +' 2'+checkbox2.checked  );
 // /*
  if (!checkbox.checked || !checkbox2.checked) {
    errorMsg.style.display = "block";
    return false;
  }

}

  </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
