<?php

require "vendor_chargily/autoload.php";
include 'saouchi_skander_inputs_from_library.php';
use Chargily\ChargilyPay\Auth\Credentials;
use Chargily\ChargilyPay\ChargilyPay;
if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
   $selected_medsin_id= $_POST['selected_medsin_id'];
   $db=config_db("allotabibi2");
   $selected_medsin_list=select_spisifique_data($db, "medsins2", $selected_medsin_id);

   $selected_medsin_name=$selected_medsin_list[0]['nom'].' '.$selected_medsin_list[0]['prenom'];
}
// الاتصال بقاعدة البيانات (أضف بياناتك هنا)
include 'config.php';
$data_encoded = $_GET['list'];
$json = base64_decode($data_encoded);
$data_list = json_decode($json, true);

// البيانات المراد إدخالها
$nom = $data_list['nom'];
$prenom = $data_list['prenom'];
$tel = $data_list['tel'];
$email = $data_list['email'];
$age = $data_list['age'];
$date = $data_list['rendezvous'];
$diabete = $data_list['diabete'];
$coeur = $data_list['coeur'];
$pression = $data_list['tension'];
$cancer = $data_list['cancer'];
$sida = $data_list['sida'];
$service_time = $data_list['service_time'];
$specialite = $data_list['specialite'];
// $selected_medsin_id dirtha sibonn 
$paye = 'non';
$link_appel='null';

// تحضير وإدخال البيانات في قاعدة البيانات
$sql = "INSERT INTO reservation_client (nom, prenom, tel, email, age, date, diabete, cœur, pression, Cancer, SIDA, service, specialite, paye,link_appel,medsin_nom) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssssssssssss", $nom, $prenom, $tel, $email, $age, $date, $diabete, $coeur, $pression, $cancer, $sida, $service_time, $specialite, $paye,$link_appel,$selected_medsin_name);

if ($stmt->execute()) {
    $id_reservation = $conn->insert_id;
} else {
    die("خطأ في إدخال البيانات: " . $stmt->error);
}
$stmt->close();

// بدء الدفع عبر Chargily
$name = $data_list['nom'];
$email = $data_list['email'];
$amount = 1000;

$credentials = new Credentials([
    "mode" => "test",
    "public" => "test_pk_LL7f55lp2DXCgWNwrqCxfgdjreSEqr3QWABVbHXt",
    "secret" => "test_sk_3Q9XKKtwmqg4hlJazDHWz4MVRUJ5GCyXLnQeWbUj",
]);

$chargily_pay = new ChargilyPay($credentials);

$checkoutData = [
    "amount" => $amount,
    "currency" => "dzd",
    "description" => "دفع من طرف $name",
    "success_url" => "https://www.allotabibi.com/allotabibi2/html/waitClient.php?id=" . $id_reservation,
    "failure_url" => "http://localhost/payment_failed.php",
    "metadata" => [
        "name" => $name,
        "email" => $email,
    ],
];

try {
    $checkout = $chargily_pay->checkouts()->create($checkoutData);

    $refClass = new ReflectionClass($checkout);
    $property = $refClass->getProperty('attributes');
    $property->setAccessible(true);
    $attributes = $property->getValue($checkout);
    $url = $attributes['url'] ?? null;

    if ($url) {
        $conn->close();
        header("Location: $url");
        exit;
    } else {
        echo "فشل في استخراج رابط الدفع!";
    }

} catch (Exception $e) {
    echo "حدث خطأ: " . $e->getMessage();
}
