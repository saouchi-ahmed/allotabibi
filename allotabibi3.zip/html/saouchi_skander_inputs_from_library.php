<?php
//======================[ Imports & Configuration ]======================
require_once 'vendor_medoo/autoload.php';

use Medoo\Medoo;

// إنشاء الاتصال بقاعدة البيانات
function config_db($dbname, $host = "localhost", $user = "root", $pass = "") {
    return new Medoo([
        'type' => 'mysql',
        'host' => $host,
        'database' => $dbname,
        'username' => $user,
        'password' => $pass,
        'charset' => 'utf8mb4'
    ]);
}

//======================[ CRUD Operations ]======================

function insert_data($db, $table, $data) {
    print_r($data);
    return $db->insert($table, $data);
}

function update_data($db, $table, $id, $data) {
    return $db->update($table, $data, ['id' => $id]);
}

function select_all_data($db, $table) {
    return $db->select($table, '*');
}

function select_spisifique_data($db, $table, $id) {
    return $db->select($table, '*', ['id' => $id]);
}

function delete_data($db, $table, $id) {
    return $db->delete($table, ['id' => $id]);
}

//======================[ Data Preparation ]======================

function prepare_data_from_post(array $fields) {
    $data = [];

    foreach ($fields as $field) {
        if ($field === 'age') {
            $data[$field] = isset($_POST[$field]) ? intval($_POST[$field]) : null;

        } elseif ($field === 'heur_travaille_teleconsultation' || $field === 'heur_travaille_adomicille') {
            $data[$field] = isset($_POST[$field]) ? implode(',', $_POST[$field]) : '';

        } elseif ($field === 'photo') {
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $tmp_name = $_FILES['photo']['tmp_name'];
                $filename = time() . '_' . basename($_FILES['photo']['name']);
                $destination = "uploads/$filename";

                if (move_uploaded_file($tmp_name, $destination)) {
                    $data[$field] = $filename; // تم رفع الصورة الجديدة
                } else {
                    $data[$field] = $_POST['old_photo'] ?? ''; // فشل الرفع، نحتفظ بالقديمة
                }
            } else {
                $data[$field] = $_POST['old_photo'] ?? ''; // لا توجد صورة جديدة
            }

        } else {
            $data[$field] = $_POST[$field] ?? null;
        }
    }

    return $data;
}


//======================[ Post Handler ]======================

function post_f($db, $table, $fields, $link_location) {
    static $edit = null;  // نخليها static لتحتفظ بالقيمة بعد الاستدعاءات
    // التعامل مع POST (إضافة أو تعديل)
   
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = prepare_data_from_post($fields);
       // print_r($data) ;
        $id = $_POST['id'] ?? null;

        if ($id) {
            update_data($db, $table, intval($id), $data);
            $edit = $data;
            $edit['id'] = intval($id);
        } else {
            $insert_id = insert_data($db, $table, $data);
            if ($insert_id) {
                $edit = $data;
                $edit['id'] = $insert_id;
            }
        }

        header("Location:" . $link_location);
        exit;
    }

    // التعامل مع حذف
    if (isset($_GET['delete'])) {
        $id = intval($_GET['delete']);
        delete_data($db, $table, $id);
        header("Location:" . $link_location);
        exit;
    }

    // في حالة وجود edit (جلب بيانات للتعديل)
    if (isset($_GET['edit'])) {
        $id = intval($_GET['edit']);
        $res = select_spisifique_data($db, $table, $id);
        $edit = $res[0] ?? null;
    }

    return $edit;
}


//======================[ HTML Form Helpers ]======================

// حقل إدخال عادي
function champ($name, $label, $type = "text") {
    global $edit;
    $value = $edit[$name] ?? '';
    return "<div class='col-md-4'>
                <label class='form-label'>$label</label>
                <input type='$type' name='$name' value='$value' class='form-control' required>
            </div>";
}
function upload_photo($name, $label) {
    global $edit;
    $value = $edit[$name] ?? '';
    $image_html = '';

    // إذا كانت هناك صورة محفوظة، نعرضها
    if (!empty($value) && file_exists("uploads/$value")) {
        $image_url = "uploads/$value";
        $image_html = "
            <div class='mb-3'>
                <p><strong>Image actuelle :</strong></p>
                <img src='" . htmlspecialchars($image_url) . "' alt='Image actuelle' class='img-thumbnail' style='max-width: 200px;'>
            </div>";
    }

    return "
    <div class='container mt-4'>
        <b>$label</b>
        $image_html
        <div class='mb-3'>
            <label for='id_$name' class='form-label'>Choisissez une nouvelle image (facultatif)</label>
            <input class='form-control' type='file' name='$name' id='id_$name'>
            <input type='hidden' name='old_photo' value='". htmlspecialchars($value) ."'>
        </div>
    </div>";
}


function checbox($name, $label) {
    global $edit;
    $value = $edit[$name] ?? 'non';
    $checked = ($value === 'oui') ? 'checked' : '';

    return "<div class='col-md-4'>
                <label>
                    <input type='hidden' name='$name' value='non'>
                    <input type='checkbox' name='$name' value='oui' $checked> $label
                </label>
            </div>";
}

// قائمة منسدلة بخيار واحد
function select_one_options($name, $label, $specialites ,$label_option) {
    global $edit;
    $value = $edit[$name] ?? '';

    $html = "<div class='col-md-4'>";
    $html .= "<label class='form-label'>$label</label>";
    $html .= "<select name='$name' class='form-control'>";
    $html .= "<option value=''>-- $label_option --</option>";

    foreach ($specialites as $key => $libelle) {
        $selected = ($value == $key) ? 'selected' : '';
        $html .= "<option value='$key' $selected>$libelle</option>";
    }

    $html .= "</select></div>";

    return $html;
}

// مجموعة من الـ checkbox لاختيار متعدد
function select_multy_chacbox($name, $label, $options) {
    global $edit;
    $selected_values = explode(',', $edit[$name] ?? '');

    $html = "<div class='col-md-12'><label class='form-label'>$label</label><div class='row'>";

    foreach ($options as $value => $label_option) {
        $checked = in_array($value, $selected_values) ? 'checked' : '';
        $html .= "<div class='col-md-3'>
                    <label><input type='checkbox' name='{$name}[]' value='$value' $checked> $label_option</label>
                  </div>";
    }

    $html .= "</div></div>";

    return $html;
}



function form_body($text_html, $input_hidden) {
    global $edit;

    $hidden_value = $edit[$input_hidden] ?? '';

    $html = '
<h2 class="mb-4 text-center">Ajouter / Modifier Médecin</h2>
<form method="POST" class="row g-3" enctype="multipart/form-data">
    <input type="hidden" name="id" value="' . htmlspecialchars($hidden_value) . '">
    ' . $text_html . '
    <div class="col-12 text-center">
        <button type="submit" class="btn btn-success">Enregistrer</button>
        <a href="gestionmedsin.php" class="btn btn-secondary">Annuler</a>
    </div>
</form>
';

    return $html;
}

function afficherTableau($liste) {
    if (empty($liste)) {
        return "<p>Aucune donnée à afficher.</p>";
    }

    $html = '';
    $html .= '<br>';
    $html .= '<hr>';
    $html .= '<div style=" overflow-x:auto;" >';
    $html .= '<h2 class="text-center">Liste des utilisateurs</h2>';
    $html .= '<table id="myTable" class="display" style="min-width: 800px;">';
    // رؤوس الجدول
    $html .= '<thead><tr>';
    foreach (array_keys($liste[0]) as $colonne) {
        $html .= '<th>' . htmlspecialchars(ucfirst($colonne)) . '</th>';
    }
    $html .= '<th>Actions</th>';
    $html .= '</tr></thead>';

    // الصفوف
    $html .= '<tbody  >';
    foreach ($liste as $row) {
        $html .= '<tr >';
        foreach ($row as $key => $valeur) {
            // إذا كان العمود هو 'photo' نعرض الصورة
            if ($key === 'photo' && !empty($valeur) && file_exists("uploads/$valeur")) {
                $html .= "<td><img src='uploads/" . htmlspecialchars($valeur) . "' alt='photo' style='max-width: 80px; max-height: 80px;' class='img-thumbnail'></td>";
            } else {
                $html .= '<td>' . htmlspecialchars($valeur) . '</td>';
            }
        }
        $html .= '<td class="text-center">
                    <a href="?edit=' . urlencode($row['id']) . '" class="btn btn-sm btn-warning m-1">Modifier</a>
                    <a href="?delete=' . urlencode($row['id']) . '" class="btn btn-sm btn-danger m-1" onclick="return confirm(\'Confirmer la suppression ?\')">Supprimer</a>
                  </td>';
        $html .= '</tr>';
    }
    $html .= '</tbody>';
    $html .= '</table>';
    $html .= '</div>';

    return $html;
}



function head_html($title)  {
   $html= '<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>'.$title.'</title>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>';
 return $html;
}
function body_html($html_text,$js_text)  {
    $html =' <body class="container py-4">
    '.$html_text.'
    '.$js_text.'
</body>
    ';
    return $html;
}
function code_html($html_text)  {
   echo ' <!DOCTYPE html>
<html lang="en">
'.$html_text.'
    </html>
    ';
}

// 14:00 -> 20:00, 17:00 -> 23:00
function isInTimeRangeFromString(string $timeRanges): bool {
    $ranges = explode(',', $timeRanges);
    $now = new DateTime();
    $nowTime = $now->format('H:i');

    foreach ($ranges as $range) {
        [$start, $end] = explode('-', trim($range));

        $startTime = DateTime::createFromFormat('H:i', $start);
        $endTime = DateTime::createFromFormat('H:i', $end);
        $currentTime = DateTime::createFromFormat('H:i', $nowTime);

        // إذا كان الوقت يعبر منتصف الليل
        if ($endTime <= $startTime) {
            $endTime->modify('+1 day');
            if ($currentTime < $startTime) {
                $currentTime->modify('+1 day');
            }
        }

        if ($currentTime >= $startTime && $currentTime <= $endTime) {
            return true;
        }
    }

    return false;
}
// 14:00,15:00,16:00,1:00
function isNowInTimeList(string $timeList): bool {
    $times = array_map('trim', explode(',', $timeList));
    date_default_timezone_set('Africa/Algiers');
    $now = (new DateTime())->format('H:00');
//echo " >> $timeList  <br> wa9t :   $now <br>  >>".in_array($now, $times);
//print_r( $times);
    return in_array($now, $times);
}


?>
