<?php
  //  header('Location: paiement_recu.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // نجمع بيانات المريض من POST
    $_SESSION['patient'] = [
        'nom' => $_POST['nom'] ?? '',
        'prenom' => $_POST['prenom'] ?? '',
        'tel' => $_POST['tel'] ?? '',
        'email' => $_POST['email'] ?? '',
        'age' => $_POST['age'] ?? '',
        'rendezvous' => $_POST['rendezvous'] ?? '',
        'diabete' => $_POST['diabete'] ?? '',
        'coeur' => $_POST['coeur'] ?? '',
        'tension' => $_POST['tension'] ?? '',
        'cancer' => $_POST['cancer'] ?? '',
        'sida' => $_POST['sida'] ?? '',
    ];

    header('Location: paiement_recu.php');
    header('Location: paiement_recu.php');
    exit();
}

?>